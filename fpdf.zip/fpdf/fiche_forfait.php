<?php
session_start();

require('fpdf.php');
if($_SESSION["autoriser"]!="oui"){
    header("location: index.php");
    exit();
  }
//connection BDD serveur
  $databases_names = 'GSB';
  $databases_pass = 'azerty';
  $databases_user = 'clement';
//don't change
  $databases_acces = 'localhost';
  $databases_port = '3306';
//connection BDD locale
  $databases_names1 = 'test_gsb';
  $databases_pass1 = '';
  $databases_user1 = 'root';

//requet et test de connection a la bdd
try{
  $pdo = new PDO("mysql:host=$databases_acces;dbname=$databases_names1;charset_utf8;","$databases_user1", "$databases_pass1");
  
  }catch (PDOException $exc){
  
  echo $exc->getMessage();
  exit();
}

class PDF extends FPDF
{
// En-tête
function Header()
{
    // Logo
    $this->Image('GSB-Logo.png',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(50,10,'Fiche frais forfait',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}
function headerFraisForfait(){
    $this->SetFont('Times','B',12);
    $this->Cell(30,10,'mois',1,0,'C');
    $this->Cell(30,10,'idFraisForfait',1,0,'C');
    $this->Cell(30,10,'quantite',1,0,'C');
    $this->Ln();

}
function viewTableFraisForfait($pdo){
    $this->SetFont('Times','B',12);
    $stmt = $pdo ->query('SELECT mois,idFraisForfait,quantite from lignefraisforfait where mois="202111"');
    while($data = $stmt->fetch(PDO::FETCH_OBJ)){
        $this->Cell(30,10,$data->mois,1,0,'L');
        $this->Cell(30,10,$data->idFraisForfait,1,0,'L');
        $this->Cell(30,10,$data->quantite,1,0,'L');
        $this->Ln();
    }
}

function HeaderHorsFraisForfait()
{
    $this->Ln(10);
    // Logo
    $this->Image('GSB-Logo.png',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(80,10,'Fiche Frais horsforfait',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

function headerTableHorsFraisForfait(){
    $this->SetFont('Times','B',12);
    $this->Cell(30,10,'mois',1,0,'C');
    $this->Cell(30,10,'libelle',1,0,'C');
    $this->Cell(30,10,'date',1,0,'C');
    $this->Cell(30,10,'montant',1,0,'C');
    $this->Ln();

}

function viewTableHorsFraisForfait($pdo){
    $this->SetFont('Times','B',12);
    $requete = $pdo ->query('SELECT mois,libelle,date,montant from lignefraishorsforfait where mois="202112"');
    while($data1 = $requete->fetch(PDO::FETCH_OBJ)){
        $this->Cell(30,10,$data1->mois,1,0,'L');
        $this->Cell(30,10,$data1->libelle,1,0,'L');
        $this->Cell(30,10,$data1->date,1,0,'L');
        $this->Cell(30,10,$data1->montant,1,0,'L');
        $this->Ln();
    }
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

// Instanciation de la classe dérivée
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('L','A4',0);
$pdf->headerFraisForfait();
$pdf->viewTableFraisForfait($pdo);
$pdf->HeaderHorsFraisForfait();
$pdf->headerTableHorsFraisForfait();
$pdf->viewTableHorsFraisForfait($pdo);
$pdf->Output();
?>